# Docker-Java-kubernetes-project
Deploying Java Applications with Docker and Kubernetes

Credit: https://github.com/danielbryantuk/oreilly-docker-java-shopping/


![logo of project](https://user-images.githubusercontent.com/103496926/211329843-62fd4ffb-1129-4c3a-9f9b-ca2d4b40efa4.png)

The workflow of the project is going to be like this in the below image ⬇️⬇️

![workflow of project logo](https://user-images.githubusercontent.com/103496926/211329892-bc005b89-9975-44cc-9bb9-88d55ce5a22a.png)

The whole blog about this project is Published on "Kubesimplify". Here, You can check : https://blog.kubesimplify.com/deploying-java-application-using-docker-and-kubernetes-devops-project#comments-list
